#!/bin/bash



make

rm -f *.o
